/*HeaderLine started*/

.headerline
 {
    border: solid #fc7a32;
    border-width:2px 1px 1px 1px;

}
/*HeaderLine ends*/

/*Header started*/

header,.NavSection,footer
{
max-width:1100px;
margin:0 auto;
height:60px;

}
header span
{
  text-align: right;
}


header .HeaderLogoSection img
{
  
    position: absolute;
    width: 40%;
    height: 60px;
    left: 30px!important;
    top: 10px;

  
}

header p
{
border-bottom:2px solid #fc7a32;
border-width:50%;
text-align: left;
}

.TextBox
{
border: none;  
outline:none;

}

header .HeaderRightSection p, header .HeaderRightSection p span, header .HeaderRightSection .TextBox
{
display:inline-block;
}


header .HeaderRightSection
{
  text-align: center;


}

p
{
padding-top: 10px;

}

a, img, input, button
{
  outline:none; border:none;
}


body
{
  margin:0; 
  padding:0; 
  overflow-x:hidden; 
  width:100%; 
  font-size:12px;
}

header .callnow
{
color:#2c3e61;

}

header .phonenumber
{
color:#fc7a32;
}


nav ul li
{
list-style:none; 
display:inline-block;
float: left;
}


.backgroundImage
{

background:url('FleetcardsUSA_Home-Img_Pump-Color_1x.jpg')no-repeat;
background-size:100%;
height:2000px;
display:block;
padding:0 !important;
margin:0;

}
.NavSection
{

color:#2F4267;
font-size:1px;

}

.ramlal1
{

color:#2B4463;

font-size:36px;

}

.ramlal2
{
color:#FE7630;
font-size:36px;



}



#example1
 {
  border: 1px solid;
  padding: 10px;
  
}

@media only screen and (max-width: 600px)
 {

  .img-fluid.float-right
  {
    display:none;
  }
}

nav ul li a:hover, nav ul li a:active, nav ul li a:visited
 {
  text-decoration: none;
}


nav ul li a:hover
{
  color:#fc7a32;
}


nav ul li a
{
  display: inline-block;
  color: #2f4267;
  text-align: center;
  text-decoration: none;
  padding: 0px 20px 10px;
  cursor: pointer;
  padding-left: 0px;
  outline: none;
}

nav ul li a, footer .FooterClass ul li a,footer .FooterClass h5
 {
  font-size: 1.70rem;
  text-decoration: none;
}

nav
{
  max-width:1280px;
margin:0 auto;
height:60px;
border:1px solid lightgrey;
}

footer .FooterClass ul li{
  margin:0 auto;
  height:100px;
  left: 30px!important;}

  footer .FooterClass , footer .CopyRightClass{
  
  background-color:  #2f4267  ;
  }
  footer .FooterClass ul li a,footer .FooterClass h5 {color: white;}
  
